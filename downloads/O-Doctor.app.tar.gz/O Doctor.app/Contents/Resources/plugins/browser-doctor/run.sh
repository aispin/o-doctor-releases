#!/bin/bash
# 浏览器残留诊断插件（O Doctor 内置）
#
# 协议：stdout 只输出 NDJSON 事件，人类可读日志走 stderr。
# 兼容 macOS 自带 bash 3.2（不用数组、不用 ${var^^}）。
#
# 性能约束：禁止逐项 fork。这里用「一次 ps」「一次 du」+ 单次 awk 生成事件。

set -uo pipefail

TMP_ROOT="${TMPDIR:-/tmp}"
TMP_ROOT="${TMP_ROOT%/}"
SHARED_TMP="/private/tmp"

# 自动化浏览器进程特征
LEAK_RE='puppeteer_dev_chrome_profile|playwright_chromiumdev_profile|Chrome for Testing|--headless.*(--remote-debugging-port|--enable-automation)'
# 会被本插件计入的 profile 目录前缀
PROFILE_RE='puppeteer_dev_chrome_profile-|playwright_chromiumdev_profile-|cdp-profile-'

log() { printf '%s\n' "$*" >&2; }

emit() { printf '%s\n' "$1"; }

# JSON 字符串转义（路径里可能有引号/反斜杠，虽然罕见）
jesc() { printf '%s' "$1" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g'; }

# ---------------------------------------------------------------- apply 模式
# 宿主写一份 TSV（id <TAB> path），插件逐行处置并回报。只动 plan 里的项，不扩大范围。
#
# 两类 id 走不同动作：
#   proc-<pid>  → kill，path 里是命令行（不用于操作，仅留痕）
#   dir-<name>  → rm -rf，path 是真实目录
APPLY_PLAN=""
prev=""
for a in "$@"; do
  [ "${prev}" = "--apply" ] && APPLY_PLAN="${a}"
  prev="${a}"
done

if [ -n "${APPLY_PLAN}" ]; then
  PLAN="${APPLY_PLAN}"
  if [ ! -f "${PLAN}" ]; then
    emit '{"type":"error","code":"no-plan","message":"找不到 plan 文件"}'
    emit '{"type":"done","exit":2}'
    exit 2
  fi

  TOTAL=$(awk 'NF' "${PLAN}" | wc -l | tr -d ' ')
  N=0; OK=0; FAIL=0

  emit '{"type":"start"}'
  emit "{\"type\":\"progress\",\"done\":0,\"total\":${TOTAL},\"phase\":\"处理中\"}"

  while IFS=$'\t' read -r item_id target; do
    [ -n "${target:-}" ] || continue
    N=$((N + 1))
    esc_id=$(printf '%s' "${item_id}" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g')
    esc_t=$(printf '%s' "${target}" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g')

    case "${item_id}" in
      proc-*)
        # id 形如 proc-1712，直接取 pid
        pid="${item_id#proc-}"
        if kill -0 "${pid}" 2>/dev/null; then
          # TERM 先礼后兵：给进程机会自己退出、清理临时目录
          kill -TERM "${pid}" 2>/dev/null
          # 最多等 2 秒
          i=0
          while kill -0 "${pid}" 2>/dev/null && [ "${i}" -lt 20 ]; do
            sleep 0.1
            i=$((i + 1))
          done
          if kill -0 "${pid}" 2>/dev/null; then
            kill -KILL "${pid}" 2>/dev/null
            sleep 0.2
          fi
        fi
        if kill -0 "${pid}" 2>/dev/null; then
          FAIL=$((FAIL + 1))
          emit "{\"type\":\"item\",\"id\":\"${esc_id}\",\"target\":\"process\",\"label\":\"pid ${pid}\",\"size\":0,\"state\":\"failed\",\"reason\":\"结束进程失败（无权限或进程不可控）\",\"path\":\"${esc_t}\"}"
        else
          OK=$((OK + 1))
          emit "{\"type\":\"item\",\"id\":\"${esc_id}\",\"target\":\"process\",\"label\":\"pid ${pid}\",\"size\":0,\"state\":\"deleted\",\"reason\":\"已结束进程\",\"path\":\"${esc_t}\"}"
        fi
        ;;
      *)
        kb=$(du -sk "${target}" 2>/dev/null | awk '{print $1}')
        [ -z "${kb}" ] && kb=0
        if rm -rf "${target}" 2>/dev/null; then
          OK=$((OK + 1))
          emit "{\"type\":\"item\",\"id\":\"${esc_id}\",\"label\":\"${esc_id}\",\"size\":$((kb * 1024)),\"state\":\"deleted\",\"path\":\"${esc_t}\"}"
        else
          FAIL=$((FAIL + 1))
          emit "{\"type\":\"item\",\"id\":\"${esc_id}\",\"label\":\"${esc_id}\",\"size\":$((kb * 1024)),\"state\":\"failed\",\"reason\":\"删除失败（权限或占用）\",\"path\":\"${esc_t}\"}"
        fi
        ;;
    esac

    emit "{\"type\":\"progress\",\"done\":${N},\"total\":${TOTAL},\"phase\":\"处理中\"}"
  done < "${PLAN}"

  if [ "${FAIL}" -gt 0 ]; then SEV="warning"; else SEV="ok"; fi
  emit "{\"type\":\"summary\",\"headline\":\"处置完成：成功 ${OK} 项，失败 ${FAIL} 项\",\"severity\":\"${SEV}\",\"metrics\":{\"deleted\":${OK},\"failed\":${FAIL},\"freedBytes\":0}}"
  emit '{"type":"done","exit":0}'
  exit 0
fi

emit "{\"type\":\"start\"}"

# ---------------------------------------------------------------- 进程扫描
PROC_TABLE="$(ps -A -ww -o pid=,command= 2>/dev/null || true)"
LEAKS="$(printf '%s\n' "${PROC_TABLE}" | grep -E "${LEAK_RE}" | grep -v 'browser-doctor' || true)"
LEAK_COUNT=$(printf '%s\n' "${LEAKS}" | awk 'NF' | wc -l | tr -d ' ')

emit "{\"type\":\"progress\",\"done\":1,\"total\":4,\"phase\":\"扫描进程表\"}"

# 残留进程：target="process"。
# 用独立形态而不是伪造 path —— 进程没有可删的路径，处置动作是 kill 而不是 rm。
# 宿主据此在确认弹窗里把「删除」换成「结束进程」，并提示可能丢失未保存数据。
if [ "${LEAK_COUNT}" -gt 0 ]; then
  printf '%s\n' "${LEAKS}" | awk 'NF {
    pid = $1
    cmd = $0
    sub(/^[ \t]*[0-9]+[ \t]+/, "", cmd)

    # 展示名：优先取 profile 标识，否则用产品名
    if (match(cmd, /(puppeteer_dev_chrome_profile|playwright_chromiumdev_profile|cdp-profile)-[A-Za-z0-9]+/)) {
      label = substr(cmd, RSTART, RLENGTH)
    } else {
      label = "Chrome for Testing"
    }

    # JSON 转义：反斜杠先转，再转引号
    esc = cmd
    gsub(/\\/, "\\\\", esc)
    gsub(/"/, "\\\"", esc)
    lab = label
    gsub(/"/, "\\\"", lab)

    # path 字段放命令行：宿主不用它删除，只用于展示与审计留痕
    printf "{\"type\":\"item\",\"target\":\"process\",\"id\":\"proc-%s\",\"pid\":%s,\"label\":\"%s\",\"command\":\"%s\",\"size\":0,\"state\":\"reclaimable\",\"path\":\"%s\"}\n", pid, pid, lab, esc, esc
  }'
fi

emit "{\"type\":\"progress\",\"done\":2,\"total\":4,\"phase\":\"扫描 profile 目录\"}"

# ---------------------------------------------------------------- 目录扫描
# 一次 du 拿到全部候选目录大小；再用 awk 判定「是否被进程引用」并生成事件。
DIR_LIST=""
for base in "${TMP_ROOT}" "${SHARED_TMP}"; do
  [ -d "${base}" ] || continue
  # shellcheck disable=SC2086
  found="$(find "${base}" -maxdepth 1 -type d \( -name 'puppeteer_dev_chrome_profile-*' \
            -o -name 'playwright_chromiumdev_profile-*' -o -name 'cdp-profile-*' \) 2>/dev/null || true)"
  [ -n "${found}" ] && DIR_LIST="${DIR_LIST}${found}
"
done

DIR_COUNT=$(printf '%s' "${DIR_LIST}" | awk 'NF' | wc -l | tr -d ' ')

if [ "${DIR_COUNT}" -gt 0 ]; then
  # 逐目录取大小（目录数量通常几十个，可接受；不递归扫描内容）
  printf '%s' "${DIR_LIST}" | awk 'NF' | while IFS= read -r d; do
    kb=$(du -sk "${d}" 2>/dev/null | awk '{print $1}')
    [ -z "${kb}" ] && kb=0
    active=0
    base=$(basename "${d}")
    printf '%s\n' "${PROC_TABLE}" | grep -qF -- "${base}" && active=1
    if [ "${active}" = "1" ]; then state="inuse"; else state="reclaimable"; fi
    printf '%s\t%s\t%s\n' "${kb}" "${state}" "${d}"
  done | awk -F'\t' '{
    kb = $1; state = $2; path = $0
    sub(/^[0-9]+\t[a-z]+\t/, "", path)
    n = path; sub(/.*\//, "", n)
    gsub(/\\/, "\\\\", path); gsub(/"/, "\\\"", path)
    gsub(/"/, "\\\"", n)
    printf "{\"type\":\"item\",\"id\":\"dir-%s\",\"label\":\"%s\",\"size\":%d,\"state\":\"%s\",\"path\":\"%s\"}\n", n, n, kb * 1024, state, path
  }'
fi

emit "{\"type\":\"progress\",\"done\":4,\"total\":4,\"phase\":\"汇总\"}"

# ---------------------------------------------------------------- 汇总
# 用两遍统计：item 已发出，这里重新算一次总量（数量小，成本可忽略）
STATS=$(printf '%s' "${DIR_LIST}" | awk 'NF' | while IFS= read -r d; do
  du -sk "${d}" 2>/dev/null | awk '{print $1}'
done | awk '{t += $1} END {printf "%d", t * 1024}')

# headline 要能独立读懂：进程不能被本工具删除，必须在文案里说清，
# 否则用户会去列表里找一条「可勾选的进程」，找不到就以为工具有 bug。
if [ "${LEAK_COUNT}" -gt 0 ] && [ "${DIR_COUNT}" -gt 0 ]; then
  SEVERITY="warning"
  HEADLINE="发现 ${DIR_COUNT} 个临时目录可清，另有 ${LEAK_COUNT} 个残留进程需手动结束"
elif [ "${DIR_COUNT}" -gt 0 ]; then
  SEVERITY="warning"
  HEADLINE="发现 ${DIR_COUNT} 个临时目录"
elif [ "${LEAK_COUNT}" -gt 0 ]; then
  SEVERITY="warning"
  HEADLINE="发现 ${LEAK_COUNT} 个残留进程（无法自动清理，见下方日志）"
else
  SEVERITY="ok"
  HEADLINE="没有发现残留"
fi

emit "{\"type\":\"summary\",\"headline\":\"${HEADLINE}\",\"severity\":\"${SEVERITY}\",\"metrics\":{\"leaks\":${LEAK_COUNT},\"profiles\":${DIR_COUNT},\"bytes\":${STATS:-0}}}"
emit "{\"type\":\"done\",\"exit\":0}"
