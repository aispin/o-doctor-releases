#!/bin/bash
# 演示插件（O Doctor）
#
# 用途：体验「安装 → 运行 → 提问 → 勾选 → 清理」完整链路。
# 全部操作局限在 ~/.odoctor-demo，不碰任何真实用户数据。
#
# 协议：stdout 只输出 NDJSON；人类可读日志走 stderr。
# 兼容 macOS 自带 bash 3.2。

set -uo pipefail

DEMO_ROOT="${HOME}/.odoctor-demo"

log() { printf '%s\n' "$*" >&2; }
emit() { printf '%s\n' "$1"; }

# 生成一个带体积的目录：$1=名字 $2=MB
make_dir() {
  mkdir -p "${DEMO_ROOT}/$1"
  /usr/bin/du -sm "${DEMO_ROOT}/$1" 2>/dev/null | awk '{print $1}' >/dev/null
  dd if=/dev/zero of="${DEMO_ROOT}/$1/fill.bin" bs=1m count="$2" 2>/dev/null
}

ensure_fixtures() {
  mkdir -p "${DEMO_ROOT}" 2>/dev/null
  # 只在不存在时创建，避免每次运行都改数据
  [ -f "${DEMO_ROOT}/.ready" ] && return 0
  make_dir "old-logs" 12
  make_dir "build-cache" 24
  make_dir "trash-candidates" 36
  mkdir -p "${DEMO_ROOT}/keep-me"
  echo "这个目录用于验证「使用中」项不可勾选" > "${DEMO_ROOT}/keep-me/note.txt"
  : > "${DEMO_ROOT}/.ready"
}

human() {
  awk -v b="${1:-0}" 'BEGIN {
    mb = b / 1048576
    if (mb < 1) printf "%d KB", (b/1024)+0.5
    else if (mb < 1024) printf "%.0f MB", mb
    else printf "%.2f GB", mb/1024
  }'
}

size_of() {
  local kb
  kb=$(/usr/bin/du -sk "$1" 2>/dev/null | awk '{print $1}')
  [ -z "${kb}" ] && kb=0
  echo $((kb * 1024))
}

# ============================================================ apply 模式
# 宿主写一份 TSV（id <TAB> path），逐行删除并回报。
APPLY_PLAN=""
prev=""
for a in "$@"; do
  [ "${prev}" = "--apply" ] && APPLY_PLAN="${a}"
  prev="${a}"
done

if [ -n "${APPLY_PLAN}" ]; then
  PLAN="${APPLY_PLAN}"
  if [ ! -f "${PLAN}" ]; then
    emit '{"type":"error","code":"no-plan","message":"找不到 plan 文件"}'
    emit '{"type":"done","exit":2}'
    exit 2
  fi

  TOTAL=$(awk 'NF' "${PLAN}" | wc -l | tr -d ' ')
  N=0; OK=0; FAIL=0; FREED=0
  emit '{"type":"start"}'
  emit "{\"type\":\"progress\",\"done\":0,\"total\":${TOTAL},\"phase\":\"删除中\"}"

  while IFS=$'\t' read -r item_id path; do
    [ -n "${path:-}" ] || continue
    N=$((N + 1))
    kb=$(/usr/bin/du -sk "${path}" 2>/dev/null | awk '{print $1}')
    [ -z "${kb}" ] && kb=0
    esc_path=$(printf '%s' "${path}" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g')
    esc_id=$(printf '%s' "${item_id}" | sed -e 's/"/\\"/g')
    if rm -rf "${path}" 2>/dev/null; then
      OK=$((OK + 1)); FREED=$((FREED + kb))
      emit "{\"type\":\"item\",\"id\":\"${esc_id}\",\"label\":\"${esc_id}\",\"size\":$((kb * 1024)),\"state\":\"deleted\",\"path\":\"${esc_path}\"}"
    else
      FAIL=$((FAIL + 1))
      emit "{\"type\":\"item\",\"id\":\"${esc_id}\",\"label\":\"${esc_id}\",\"size\":$((kb * 1024)),\"state\":\"failed\",\"reason\":\"删除失败\",\"path\":\"${esc_path}\"}"
    fi
    emit "{\"type\":\"progress\",\"done\":${N},\"total\":${TOTAL},\"phase\":\"删除中\"}"
  done < "${PLAN}"

  emit "{\"type\":\"summary\",\"headline\":\"已释放 $(human "$((FREED * 1024))")，成功 ${OK} 项，失败 ${FAIL} 项\",\"severity\":\"$( [ "${FAIL}" -gt 0 ] && echo warning || echo ok )\",\"metrics\":{\"deleted\":${OK},\"failed\":${FAIL},\"freedBytes\":$((FREED * 1024))}}"
  emit '{"type":"done","exit":0}'
  exit 0
fi

# ============================================================ 扫描模式
emit '{"type":"start"}'
emit '{"type":"progress","done":0,"total":3,"phase":"准备演示数据"}'

ensure_fixtures

emit '{"type":"progress","done":1,"total":3,"phase":"统计目录体积"}'

# 先问一次要不要包含「保留区」——演示 ask 通道
INCLUDE_KEEP="no"
if [ -z "${ODOCTOR_NON_INTERACTIVE:-}" ]; then
  emit '{"type":"ask","id":"q1","kind":"confirm","prompt":"演示插件需要确认：是否把 keep-me 目录也纳入检查？（它应该显示为「使用中」）","default":false}'
  if IFS= read -r reply; then
    case "${reply}" in
      *'"answer":true'*) INCLUDE_KEEP="yes" ;;
    esac
  fi
fi
log "include_keep=${INCLUDE_KEEP}"

emit '{"type":"progress","done":2,"total":3,"phase":"汇总"}'

emit "{\"type\":\"item\",\"id\":\"old-logs\",\"label\":\"old-logs\",\"size\":$(size_of "${DEMO_ROOT}/old-logs"),\"state\":\"reclaimable\",\"path\":\"${DEMO_ROOT}/old-logs\"}"
emit "{\"type\":\"item\",\"id\":\"build-cache\",\"label\":\"build-cache\",\"size\":$(size_of "${DEMO_ROOT}/build-cache"),\"state\":\"reclaimable\",\"path\":\"${DEMO_ROOT}/build-cache\"}"
emit "{\"type\":\"item\",\"id\":\"trash-candidates\",\"label\":\"trash-candidates\",\"size\":$(size_of "${DEMO_ROOT}/trash-candidates"),\"state\":\"confirm\",\"path\":\"${DEMO_ROOT}/trash-candidates\"}"

if [ "${INCLUDE_KEEP}" = "yes" ]; then
  emit "{\"type\":\"item\",\"id\":\"keep-me\",\"label\":\"keep-me（使用中）\",\"size\":$(size_of "${DEMO_ROOT}/keep-me"),\"state\":\"inuse\"}"
fi

RECLAIM=$(( $(size_of "${DEMO_ROOT}/old-logs") + $(size_of "${DEMO_ROOT}/build-cache") + $(size_of "${DEMO_ROOT}/trash-candidates") ))
emit "{\"type\":\"progress\",\"done\":3,\"total\":3,\"phase\":\"完成\"}"
emit "{\"type\":\"summary\",\"headline\":\"演示插件发现 3 项可清理，共 $(human "${RECLAIM}")\",\"severity\":\"warning\",\"metrics\":{\"reclaimable\":${RECLAIM}}}"
emit '{"type":"done","exit":0}'