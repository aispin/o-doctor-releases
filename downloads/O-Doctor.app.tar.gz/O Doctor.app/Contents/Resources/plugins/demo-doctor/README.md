# 演示插件（demo-doctor）

用于体验 O Doctor 的**安装 → 运行 → 提问 → 勾选 → 清理**完整链路。

## 它做什么

在 `~/.odoctor-demo` 下生成三个演示目录（共约 72 MB），扫描后标记为可清理：

| 目录 | 体积 | 状态 |
|---|---|---|
| `old-logs` | 12 MB | 可清理 |
| `build-cache` | 24 MB | 可清理 |
| `trash-candidates` | 36 MB | 可清理（需确认） |
| `keep-me` | 很小 | 使用中（不可勾选） |

**只在这个目录里操作，不碰任何真实数据。** 想恢复正常状态，直接 `rm -rf ~/.odoctor-demo`。

## 会弹一次窗

运行时它会问一句「是否把 keep-me 也纳入检查」——这是用来验证 `ask` 交互通道的。
选「是」就会多出一行「使用中」的项，用来验证这类项不可勾选。

按 tech.md 的约束，这是**唯一一次**提问，且能用两阶段解决的不该用 ask。

## 安装方式

在插件页点「添加插件」，输入其中一种：

```
aispin/x-tools                                  # 从 GitHub 拉，走 plugins.json 索引
/Volumes/Pluto/dev/github/aispin/x-tools/apps/o-doctor   # 本地目录
```

装完默认是**关闭**状态，需要手动启用才能运行。
