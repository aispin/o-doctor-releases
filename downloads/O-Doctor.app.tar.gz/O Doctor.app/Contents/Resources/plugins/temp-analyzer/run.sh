#!/bin/bash
# 系统盘空间守护 · 临时目录诊断（O Doctor 官方插件）
#
# 协议：stdout 只输出 NDJSON，人类可读日志走 stderr。
# 兼容 macOS 自带 bash 3.2。
#
# 设计依据见 PRD §7.0.1 ~ §7.0.4：
# 1. 按扫描根目录分组，组名就是路径本身
# 2. 组内 Top 5 + 50MB 门槛，取大项几乎等于取全部（实测 Top1 占 76~86%）
# 3. 不区分「可清理 / 需确认」，只报事实 —— 那是插件猜文件名得出的策略，用户不该理解
# 4. 不可勾选只有两种：有进程占用（busy）、本身是符号链接（symlink）
# 5. 体积只用一次 du -ak。不用 find 计数：同一棵树 find 要 583s，
#    CPU 只占 0.5s，其余是 macOS 对临时目录的 TCC 权限检查（tech.md §5.3）

set -uo pipefail

TMP_ROOT="${TMPDIR:-/tmp}"
TMP_ROOT="${TMP_ROOT%/}"
SHARED_TMP="/private/tmp"

TOP_N=5
MIN_KB=51200          # 50 MB 门槛：低于此值不进列表

emit() { printf '%s\n' "$1"; }

# JSON 字符串转义
jesc() { printf '%s' "$1" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g'; }

# ---------------------------------------------------------------- apply 模式
# 宿主写一份 TSV（id <TAB> path），插件逐行删除并回报。
# 只删 plan 里的路径，不扩大范围。符号链接会在删除前再确认一次。
APPLY_PLAN=""
prev=""
for a in "$@"; do
  [ "${prev}" = "--apply" ] && APPLY_PLAN="${a}"
  prev="${a}"
done

if [ -n "${APPLY_PLAN}" ]; then
  PLAN="${APPLY_PLAN}"
  [ -f "${PLAN}" ] || { emit '{"type":"error","code":"no-plan","message":"找不到 plan 文件"}'; emit '{"type":"done","exit":2}'; exit 2; }

  TOTAL=$(awk 'NF' "${PLAN}" | wc -l | tr -d ' ')
  N=0; OK=0; FAIL=0; FREED=0
  emit '{"type":"start"}'
  emit "{\"type\":\"progress\",\"done\":0,\"total\":${TOTAL},\"phase\":\"删除中\"}"

  while IFS=$'\t' read -r item_id path; do
    [ -n "${path:-}" ] || continue
    N=$((N + 1))

    # 符号链接只删链接本身，绝不跟随。
    # rm -rf "$p/" 会沿链接删掉目标里的真实文件，所以先判类型再决定。
    if [ -L "${path}" ]; then
      kb=0
      if rm -f "${path}" 2>/dev/null; then
        OK=$((OK + 1))
        emit "{\"type\":\"item\",\"id\":\"$(jesc "${item_id}")\",\"label\":\"$(jesc "${item_id}")\",\"size\":0,\"state\":\"deleted\",\"reason\":\"已移除符号链接（目标未动）\",\"path\":\"$(jesc "${path}")\"}"
      else
        FAIL=$((FAIL + 1))
        emit "{\"type\":\"item\",\"id\":\"$(jesc "${item_id}")\",\"label\":\"$(jesc "${item_id}")\",\"size\":0,\"state\":\"failed\",\"reason\":\"移除符号链接失败\",\"path\":\"$(jesc "${path}")\"}"
      fi
    else
      kb=$(du -sk "${path}" 2>/dev/null | awk '{print $1}')
      [ -z "${kb}" ] && kb=0
      if rm -rf "${path}" 2>/dev/null; then
        OK=$((OK + 1)); FREED=$((FREED + kb))
        emit "{\"type\":\"item\",\"id\":\"$(jesc "${item_id}")\",\"label\":\"$(jesc "${item_id}")\",\"size\":$((kb * 1024)),\"state\":\"deleted\",\"path\":\"$(jesc "${path}")\"}"
      else
        FAIL=$((FAIL + 1))
        emit "{\"type\":\"item\",\"id\":\"$(jesc "${item_id}")\",\"label\":\"$(jesc "${item_id}")\",\"size\":$((kb * 1024)),\"state\":\"failed\",\"reason\":\"删除失败（权限或占用）\",\"path\":\"$(jesc "${path}")\"}"
      fi
    fi

    emit "{\"type\":\"progress\",\"done\":${N},\"total\":${TOTAL},\"phase\":\"删除中\"}"
  done < "${PLAN}"

  gb() { awk -v k="${1:-0}" 'BEGIN { if (k < 1048576) printf "%.0f MB", k/1024; else printf "%.1f GB", k/1024/1024 }'; }
  emit "{\"type\":\"summary\",\"headline\":\"已释放 $(gb "${FREED}")，成功 ${OK} 项，失败 ${FAIL} 项\",\"severity\":\"$( [ "${FAIL}" -gt 0 ] && echo warning || echo ok )\",\"metrics\":{\"deleted\":${OK},\"failed\":${FAIL},\"freedBytes\":$((FREED * 1024))}}"
  emit '{"type":"done","exit":0}'
  exit 0
fi


# ================================================================ 扫描模式
#
# 目标很明确：**找出临时目录里占地方的大块头，让用户勾选删掉。**
# 不是做磁盘容量审计，所以：
#
# - 不需要精确文件数。du 的条目数够用，少一次 80 万行的目录推断。
# - 不需要每个顶层条目都列出来。组内 Top N 就覆盖了绝大部分体积
#   （实测 $TMPDIR Top1 占 85.9%、~/.cache Top1 占 76.2%）。
# - 按扫描根目录分组，组名就是路径。位置是用户判断风险的第一线索。
#
# 取数只用一次 du -ak：它用 Darwin 的 fts(3)，是全机最快的遍历方式
# （比手写 Rust 快 45%，比 find 快 36 倍——后者慢在 TCC 权限检查）。
#
# 注意 du -a 默认 512 字节块、du -sk 是 1024，混用会差 2 倍，必须统一 -ak。

emit '{"type":"start"}'

TOTAL_KB=0           # 全作用域体积
STEP=0

# 进程表只读一次，用于判定 busy（不逐条 fork ps）
PROC_TABLE="$(ps -A -ww -o command= 2>/dev/null || true)"

# scan_root <路径> <展示标签> <默认勾选> <风险类型>
scan_root() {
  root="$1"
  label="$2"
  want_sel="$3"
  risk="$4"
  [ -d "${root}" ] || return 0

  STEP=$((STEP + 1))
  emit "{\"type\":\"progress\",\"done\":${STEP},\"total\":4,\"phase\":\"扫描 ${label}\"}"

  work="$(mktemp -t odtemp)"

  # 一次 du -ak，单趟 awk 按顶层条目聚合体积。
  # du 是后序遍历（目录行在其子条目之后），所以取体积最大值而不是首次值。
  du -ak "${root}" 2>/dev/null | awk -v r="${root}" '
    BEGIN { rl = length(r) + 1 }
    {
      kb = $1
      p = $0
      sub(/^[ \t]*[0-9]+[ \t]+/, "", p)
      if (p == r) next

      rel = substr(p, rl + 1)
      i = index(rel, "/")
      top = (i ? substr(rel, 1, i - 1) : rel)

      if (!(top in sz) || kb + 0 > sz[top]) sz[top] = kb + 0
      seen[top] = 1
    }
    END {
      for (k in seen) printf "%d\t%s\n", sz[k], k
    }
  ' | sort -rn > "${work}.agg"

  if [ ! -s "${work}.agg" ]; then
    rm -f "${work}".*
    return 0
  fi

  read -r grp_n grp_kb <<EOF
$(awk -F'\t' '{ n++; s += $1 } END { printf "%d %d", n, s }' "${work}.agg")
EOF

  TOTAL_KB=$((TOTAL_KB + grp_kb))

  gid="g-$(printf '%s' "${label}" | tr -c 'A-Za-z0-9' '-' | sed -e 's/--*/-/g' -e 's/-$//')"

  omitted_n=$((grp_n > TOP_N ? grp_n - TOP_N : 0))
  omitted_kb=0
  if [ "${omitted_n}" -gt 0 ]; then
    omitted_kb=$(awk -F'\t' -v skip="${TOP_N}" 'NR > skip { s += $1 } END { print s + 0 }' "${work}.agg")
  fi

  # --- 发 group ---
  sel_json=""
  [ "${want_sel}" = "false" ] && sel_json=',"defaultSelected":false'
  risk_json=""
  [ -n "${risk}" ] && risk_json=",\"risk\":\"${risk}\""
  om_json=""
  [ "${omitted_n}" -gt 0 ] && om_json=",\"omitted\":{\"count\":${omitted_n},\"size\":$((omitted_kb * 1024))}"
  emit "{\"type\":\"group\",\"id\":\"${gid}\",\"label\":\"$(jesc "${label}")\",\"count\":${grp_n},\"size\":$((grp_kb * 1024))${sel_json}${risk_json}${om_json}}"

  # --- 逐条发 item：仅 Top N 且 >= 门槛 ---
  head -n "${TOP_N}" "${work}.agg" | while IFS=$'\t' read -r kb name; do
    [ "${kb}" -ge "${MIN_KB}" ] || continue

    full="${root}/${name}"
    esc_name=$(jesc "${name}")
    esc_full=$(jesc "${full}")

    # 符号链接：显示但不处理，体积不计入「可释放」。
    # 判据必须用 lstat —— du 的条目数无法区分「符号链接」和「单文件」。
    # 只对 Top N 做（最多 5 次，成本可忽略）。
    if [ -L "${full}" ]; then
      emit "{\"type\":\"item\",\"id\":\"itm-${esc_name}\",\"label\":\"${esc_name}\",\"size\":$((kb * 1024)),\"state\":\"reclaimable\",\"path\":\"${esc_full}\",\"group\":\"${gid}\",\"symlink\":true}"
      continue
    fi

    busy_json=""
    if [ -n "${PROC_TABLE}" ] && printf '%s\n' "${PROC_TABLE}" | grep -qF -- "${full}" 2>/dev/null; then
      busy_json=',"busy":true'
    fi

    emit "{\"type\":\"item\",\"id\":\"itm-${esc_name}\",\"label\":\"${esc_name}\",\"size\":$((kb * 1024)),\"state\":\"reclaimable\",\"path\":\"${esc_full}\",\"group\":\"${gid}\"${busy_json}}"
  done

  rm -f "${work}".*
}

scan_root "${TMP_ROOT}" '$TMPDIR' true ""
scan_root "${SHARED_TMP}" '/private/tmp' true ""
scan_root "${HOME}/.cache" '~/.cache' false "app-cache"
scan_root "${HOME}/Library/Caches" '~/Library/Caches' false "app-cache"

emit '{"type":"progress","done":4,"total":4,"phase":"汇总"}'

if [ "${TOTAL_KB}" -gt 0 ]; then SEVERITY="warning"; else SEVERITY="ok"; fi
HEADLINE="临时目录共占用 $(awk -v k="${TOTAL_KB}" 'BEGIN { if (k < 1048576) printf "%.0f MB", k/1024; else printf "%.1f GB", k/1024/1024 }')"

emit "{\"type\":\"summary\",\"headline\":\"${HEADLINE}\",\"severity\":\"${SEVERITY}\",\"metrics\":{\"totalBytes\":$((TOTAL_KB * 1024))}}"
emit '{"type":"done","exit":0}'